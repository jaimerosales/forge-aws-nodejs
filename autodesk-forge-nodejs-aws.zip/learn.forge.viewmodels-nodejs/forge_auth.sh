# Copy to forge_auth.sh, replace with your own data and execute
# in your terminal like "source forge_auth.sh" before running the scripts.
# Check with "echo $FORGE_BUCKET_NAME" that your variables got exported.
# Make sure you don't publish your credentials!
export FORGE_CLIENT_ID='EYaKTxkRjG9eox3AE6stwI175E4deeET'
export FORGE_CLIENT_SECRET='AYJSLVlaIJebFYGR'
